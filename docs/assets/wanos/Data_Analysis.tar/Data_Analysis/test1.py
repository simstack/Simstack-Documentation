import numpy as np
import matplotlib.pyplot as plt
import os, fnmatch
import sys
import re

nums = re.compile(r"[+-]?\d+(?:\.\d+)?")  # Regular expression
file = '3_QEOUT'
Search_parameter = "Mol_"
with open(file, "r") as file1:
    for line in file1.readlines():
        if Search_parameter in line:
            idx1 = line.find('"')
            idx2 = line.find('"', idx1 + 1)
            field = line[idx1 + 1:idx2]
            array = nums.findall(field)
            print (array)




