## Project: Data_Analysis

This WaNo extract two (x,y) variable of many files, which has a certain pattern in its name.

### Inputs parameters
- File_Name
- var_1 (energy)
- var_2 (Mol_)

<img src="WaNo_Data_Analysis.png"  width="600" height="500">

### Output file

A figure .png and table sorted by the x coordinate variable. 

